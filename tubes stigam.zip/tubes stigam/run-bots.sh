#!/bin/bash

python main.py --logic Stigam --email=bot1@email.com --name=Stigam --password=123 --team etimo &